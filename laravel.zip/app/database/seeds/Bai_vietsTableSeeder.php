<?php

class Bai_vietsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('bai_viets')->truncate();

		$bai_viets = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('bai_viets')->insert($bai_viets);
	}

}
