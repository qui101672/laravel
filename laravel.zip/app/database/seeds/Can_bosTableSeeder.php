<?php

class Can_bosTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('can_bos')->truncate();

		$can_bos = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('can_bos')->insert($can_bos);
	}

}
