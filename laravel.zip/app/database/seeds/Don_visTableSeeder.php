<?php

class Don_visTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('don_vis')->truncate();

		$don_vis = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('don_vis')->insert($don_vis);
	}

}
