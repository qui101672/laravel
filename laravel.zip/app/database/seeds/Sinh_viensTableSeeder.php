<?php

class Sinh_viensTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('sinh_viens')->truncate();

		$sinh_viens = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('sinh_viens')->insert($sinh_viens);
	}

}
