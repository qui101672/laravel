<?php

class The_loai_bai_vietsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('the_loai_bai_viets')->truncate();

		$the_loai_bai_viets = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('the_loai_bai_viets')->insert($the_loai_bai_viets);
	}

}
