<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/
include('config/constant/roles.php');

Route::get('/', array('as' => 'home', 'uses' => 'NguoiDungBaiVietController@index'));

Route::post('login', array('before' => 'csrf', 'uses' => 'Tai_khoansController@login'));

Route::get('login', array('as' => 'login', function () { 
	return View::make('login');
}))->before('guest');

Route::get('logout', array('as' => 'logout', function () { 
	Auth::logout();
    return Redirect::route('home')
        ->with('flash_notice', 'Bạn đã đăng xuất khỏi hệ thống!!!');
}))->before('auth');

Route::get('profile', array('uses' => 'Tai_khoansController@profile'))->before('auth');

Route::resource('tin_tuc', 'NguoiDungBaiVietController');
Route::resource('bai_viet','QuanTriBaiVietController');

