<!-- ============================  Main Tagline Ends ============================ -->

        <div class="row-fluid">
            <footer >
			    <div class="container">
			        <div class="row"  style="width:80%;margin-left: 50px;">
			            <div class="span4">
			                <div class="footer-widget">
			                    <h5 class="title">Sơ Đồ Web</h5>
			                    <p class="content">Brownie candy ice cream. Jelly chupa chups chupa chups toocake. Dessert apple pie lemon drops. </p>
			                    <p class="content">Candy canes tiramisu wypa gummies jujubes macaroon Sweet roll biscuiti apple pie sweet.</p>
			                </div> <!-- end footer-widget -->
			            </div> <!-- end span3 -->

			            <div class="span4">
			                <div class="footer-widget">
			                    <h5 class="title">Liên Hệ</h5>
			                    <p class="content">Jelly beans tootsie roll oat cake dingo pie wafer sweet roll. Sweet gerbread halvah.</p>
			                    <form action="" class='subscribe-form'>
			                        <div class="input-append">
			                            <input class="input-large" id="appendedInput" type="text">
			                            <span class="add-on"><i class="icon-envelope-alt"></i></span>
			                        </div>
			                    </form> <!-- end subscribe-form -->
			                </div> <!-- end footer-widget -->
			            </div> <!-- end span3 -->

			            <div class="span4">
			                <div class="footer-widget">
			                    <h5 class="title">Liên Kết</h5>
			                    <ul class="unstyled twitter-timeline">
			                        <li>@ Brownie candy ice cream. Jelly chupa chups chupa chups toocake. <p><small>7 Hours ago</small></p></li>
			                        <li>@Brownie candy ice cream. Jelly chupa chups chupa chups toocake. <p><small>7 Hours ago</small></p></li>
			                    </ul>

			                </div> <!-- end footer-widget -->
			            </div> <!-- end span3 -->



			        </div> <!-- end row -->
			    </div> <!-- end container -->
			</footer>
			<section class="subfooter">
			    <div class="container">
			        <div class="row">
			            <div class="span7 offset1">
			                <p class="rights">Trường Đại học Cần Thơ (Can Tho University)
Khu II, đường 3/2, P. Xuân Khánh, Q. Ninh Kiều, TP. Cần Thơ.
			                </p>
			                <p  class="rights">
			                	Điện thoại: (84-0710) 3832663 - (84-0710) 3838474; Fax: (84-0710) 3838474; Email: dhct@ctu.edu.vn.
			                </p>

			            </div> <!-- end row-->
			        </div> <!--end container -->
			</section> <!-- end subfooter --> 
        </div>
        <div>