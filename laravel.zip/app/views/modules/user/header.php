 <!-- ============================  Dropdown Info Start ============================ -->
		<section class="dropdown-info">
		    <div class="container">
		        <div class="row">
		            <div class="span10">
		                <div class="contact-info-widget pull-right">
		                    <a href="#" id="info-activator"><i class="icon-angle-down"></i></a>
		                    <ul class="unstyled inline">
		                        <li><i class="icon-phone icon-large"></i> <span class="info">+84 939 84 81 85</span></li>
		                        <li><i class="icon-envelope-alt icon-large"></i> <span class="info">admin@webctucit.com</span></li>
		                    </ul>
		                </div> <!-- end contact-info-widget -->
		            </div> <!-- end span12 -->
		        </div> <!-- end row -->
		    </div> <!-- end container -->
		</section> <!-- end dropdown-info -->

		<!-- ============================  Dropdown Info End ============================ -->
		<div class="flexslider-container v2 container-fluid">
		    <div class="header-banner">
		        <img src="<?php echo asset('public/user/img/bg.png');?>" alt="img">
		    </div>
		</div>
